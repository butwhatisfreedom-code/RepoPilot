# Security Policy

## Supported versions

The latest version on the default branch is the only version currently supported.

## Reporting a vulnerability

Please do not publish exploitable vulnerability details in a public issue.

Report suspected security issues privately to the repository maintainer through GitHub's private vulnerability reporting feature, if enabled. Include:

- A concise description of the issue
- Steps to reproduce
- Potential impact
- Any suggested mitigation

Do not include real credentials, access tokens, or other secrets in reports.
