"""Command-line interface for RepoPilot."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

from .health import inspect_repository
from .triage import triage_issues


def _write_output(data, output: str | None) -> None:
    rendered = json.dumps(data, ensure_ascii=False, indent=2)
    if output:
        Path(output).write_text(rendered + "\n", encoding="utf-8")
    else:
        print(rendered)


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="repopilot",
        description="Local-first, read-only open-source repository maintenance tools.",
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    triage = subparsers.add_parser("triage", help="Classify issues from a local JSON file.")
    triage.add_argument("input", help="Path to a JSON array of issue objects.")
    triage.add_argument("--format", choices=("text", "json"), default="text")
    triage.add_argument("--output", help="Optional output file.")

    health = subparsers.add_parser("health", help="Check common repository files.")
    health.add_argument("path", nargs="?", default=".")
    health.add_argument("--format", choices=("text", "json"), default="text")
    health.add_argument("--output", help="Optional output file.")
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = _build_parser()
    args = parser.parse_args(argv)

    try:
        if args.command == "triage":
            raw = json.loads(Path(args.input).read_text(encoding="utf-8"))
            if not isinstance(raw, list) or not all(isinstance(x, dict) for x in raw):
                raise ValueError("Input JSON must be an array of objects.")
            results = [item.to_dict() for item in triage_issues(raw)]
            if args.format == "json":
                _write_output(results, args.output)
            else:
                lines = [
                    f"#{item['number'] if item['number'] is not None else '-'} "
                    f"[{item['category']}] {item['title']} "
                    f"(confidence: {item['confidence']})"
                    for item in results
                ]
                rendered = "\n".join(lines) if lines else "No issues found."
                if args.output:
                    Path(args.output).write_text(rendered + "\n", encoding="utf-8")
                else:
                    print(rendered)
            return 0

        report = inspect_repository(args.path)
        if args.format == "json":
            _write_output(report, args.output)
        else:
            lines = [
                f"Repository health: {report['score']}/{report['total']} "
                f"({report['percentage']}%)",
            ]
            for name, item in report["checks"].items():
                status = "OK" if item["present"] else "MISSING"
                suffix = f" — found as {item['found_as']}" if item["found_as"] else ""
                lines.append(f"{status}: {name}{suffix}")
            rendered = "\n".join(lines)
            if args.output:
                Path(args.output).write_text(rendered + "\n", encoding="utf-8")
            else:
                print(rendered)
        return 0

    except (OSError, json.JSONDecodeError, ValueError) as exc:
        print(f"repopilot: error: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
