"""Deterministic, local-only issue classification."""

from __future__ import annotations

from dataclasses import asdict, dataclass
import re
from typing import Any, Iterable


@dataclass(frozen=True)
class TriageResult:
    number: int | str | None
    title: str
    category: str
    confidence: str
    reason: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


_RULES: tuple[tuple[str, tuple[str, ...], str], ...] = (
    ("bug", ("bug", "crash", "crashes", "error", "exception", "broken",
             "does not work", "doesn't work", "fail", "fails", "regression"), "Bug-related wording"),
    ("feature", ("feature", "enhancement", " add ", "support for", "would be nice",
                 "please implement", "request"), "Feature-request wording"),
    ("documentation", ("documentation", "docs", "readme", "typo", "spelling",
                       "clarify", "example is wrong"), "Documentation-related wording"),
    ("question", ("how do i", "how can i", "why does", "question", "help",
                  "is it possible", "what is"), "Question or help wording"),
)


def classify_issue(issue: dict[str, Any]) -> TriageResult:
    """Classify one issue-like dictionary using simple keyword rules."""
    title = str(issue.get("title", "")).strip()
    body = str(issue.get("body", "")).strip()
    haystack = f" {title.lower()} {body.lower()} "
    number = issue.get("number")

    for category, keywords, reason in _RULES:
        if any(keyword in haystack for keyword in keywords):
            return TriageResult(number, title, category, "medium", reason)

    return TriageResult(number, title, "other", "low", "No matching triage rule")


def triage_issues(issues: Iterable[dict[str, Any]]) -> list[TriageResult]:
    """Classify a sequence of issue-like dictionaries."""
    return [classify_issue(issue) for issue in issues]
