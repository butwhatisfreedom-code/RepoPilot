"""Local repository health checks."""

from __future__ import annotations

from pathlib import Path
from typing import Any


CHECKS = {
    "README.md": ("README.md", "README.rst", "README"),
    "LICENSE": ("LICENSE", "LICENSE.md", "LICENSE.txt", "COPYING"),
    "CONTRIBUTING.md": ("CONTRIBUTING.md", "CONTRIBUTING"),
    "SECURITY.md": ("SECURITY.md", "SECURITY"),
}


def inspect_repository(path: str | Path) -> dict[str, Any]:
    """Check for common project documentation files without network access."""
    root = Path(path).expanduser().resolve()
    if not root.exists() or not root.is_dir():
        raise ValueError(f"Not a directory: {root}")

    results = {}
    for canonical_name, candidates in CHECKS.items():
        found = next((name for name in candidates if (root / name).is_file()), None)
        results[canonical_name] = {
            "present": found is not None,
            "found_as": found,
        }

    present = sum(1 for item in results.values() if item["present"])
    total = len(results)
    return {
        "path": str(root),
        "score": present,
        "total": total,
        "percentage": round((present / total) * 100),
        "checks": results,
    }
