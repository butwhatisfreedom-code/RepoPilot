import json

import pytest

from repopilot.health import inspect_repository
from repopilot.triage import classify_issue, triage_issues


@pytest.mark.parametrize(
    ("issue", "expected"),
    [
        ({"number": 1, "title": "App crashes on startup"}, "bug"),
        ({"number": 2, "title": "Feature request: dark mode"}, "feature"),
        ({"number": 3, "title": "How do I configure this?"}, "question"),
        ({"number": 4, "title": "Typo in README"}, "documentation"),
        ({"number": 5, "title": "Hello there"}, "other"),
    ],
)
def test_classify_issue(issue, expected):
    assert classify_issue(issue).category == expected


def test_triage_preserves_issue_number():
    result = triage_issues([{"number": 42, "title": "A crash"}])
    assert result[0].number == 42


def test_health_check_detects_files(tmp_path):
    (tmp_path / "README.md").write_text("# Example", encoding="utf-8")
    (tmp_path / "LICENSE").write_text("MIT", encoding="utf-8")
    report = inspect_repository(tmp_path)
    assert report["score"] == 2
    assert report["checks"]["README.md"]["present"] is True
    assert report["checks"]["SECURITY.md"]["present"] is False


def test_health_rejects_missing_directory(tmp_path):
    with pytest.raises(ValueError):
        inspect_repository(tmp_path / "does-not-exist")
