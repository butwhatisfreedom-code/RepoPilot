# RepoPilot

AI-powered open-source repository maintenance toolkit.

RepoPilot is a local-first toolkit that helps maintainers inspect repository health and triage issue reports. The first release is deliberately deterministic and read-only: it does not need an API key, make network requests, execute repository code, or modify GitHub issues.

## Features

- **Issue triage:** classify issue titles and bodies as `bug`, `feature`, `question`, `documentation`, or `other`.
- **Repository health:** check for common project-maintenance files such as README, license, contributing guide, and security policy.
- **Machine-readable output:** emit JSON for use in scripts and CI.
- **Safe by default:** local files only; no GitHub write operations.

## Requirements

- Python 3.10 or newer

## Install from source

```bash
git clone https://github.com/butwhatisfreedom-code/RepoPilot.git
cd RepoPilot
python -m pip install -e .
```

## Quick start

### 1. Triage a local issue export

Create `issues.json`:

```json
[
  {
    "number": 1,
    "title": "Application crashes when opening settings",
    "body": "The app raises an exception every time I open settings."
  },
  {
    "number": 2,
    "title": "Please add dark mode",
    "body": "A dark theme would make the interface easier to use."
  }
]
```

Run:

```bash
repopilot triage issues.json
```

JSON output:

```bash
repopilot triage issues.json --format json
```

### 2. Check repository health

Run from a repository directory:

```bash
repopilot health .
```

JSON output:

```bash
repopilot health . --format json
```

## Development

```bash
python -m pip install -e ".[dev]"
pytest
```

## Safety and privacy

- RepoPilot currently reads only files explicitly supplied on the command line.
- It does not connect to GitHub or any other remote service.
- It does not execute code from the inspected repository.
- It does not create comments, labels, branches, commits, or pull requests.
- Classification is heuristic and should be reviewed by a human.

## Roadmap

- [ ] Optional GitHub issue import using a read-only token
- [ ] Configurable triage rules
- [ ] Duplicate-issue hints
- [ ] Release-note drafting from local data
- [ ] GitHub Actions integration

## License

MIT. See [LICENSE](LICENSE).
