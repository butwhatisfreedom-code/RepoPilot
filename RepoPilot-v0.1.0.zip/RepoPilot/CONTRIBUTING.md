# Contributing to RepoPilot

Thanks for considering a contribution!

## Development setup

1. Use Python 3.10 or newer.
2. Clone the repository.
3. Install development dependencies:

   ```bash
   python -m pip install -e ".[dev]"
   ```

4. Run the test suite:

   ```bash
   pytest
   ```

## Contribution guidelines

- Keep the first release local-first and read-only.
- Add or update tests for behavior changes.
- Prefer small, focused pull requests.
- Document new command-line options in the README.
- Do not add network access or GitHub write actions without a clearly documented design and explicit maintainer approval.

## Reporting bugs

Open an issue with steps to reproduce, expected behavior, actual behavior, and relevant error output. Remove secrets and personal information before posting logs.
